﻿using ComedyShow.Model;
using ComedyShow.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections;

namespace ComedyShow.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationsController : ControllerBase
    {
       
        private readonly IRegistrationRepository _registrationRepository;
        private readonly ILogger<RegistrationsController> _logger;

        public RegistrationsController(IRegistrationRepository registrationRepository,
          ILogger<RegistrationsController> logger)
        {
            
            _registrationRepository = registrationRepository;
            _logger = logger;

        }


        // GET: api/Registrations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Registration>>> GetRegistration()
        {
            return await _registrationRepository.GetRegistration();
        }

        // GET: api/Registrations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Registration>> GetRegistration(int id)
        {
            try
            {
                return await _registrationRepository.GetRegistration(id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return NotFound();
            }
        }

        [HttpPost("{email}/{password}")]
        public async Task<ActionResult<Registration>> GetRegistration(string email, string password)
        {
            Hashtable err = new Hashtable();
            {
                try
                {
                    var authUser = await _registrationRepository.GetRegistration(email, password);
                    if (authUser != null)
                    {

                        return Ok(authUser);
                    }


                    else
                    {
                        err.Add("Status", "Error");

                        err.Add("Message", "Invalid Credentials");

                        return Ok(err);
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }


        // PUT: api/Registrations/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        /*public async Task<IActionResult> PutRegistration(int id, Registration registration)
        {
            if (id != registration.userid)
            {
                return BadRequest();
            }

            var user = _context.Registrations.FirstOrDefault(t => t.userid == registration.userid);
            if (user != null)
            {
                user.username = registration.username;
                user.password = registration.password;
                user.email = registration.email;
                user.confirmpassword = registration.confirmpassword;

            }
            _context.SaveChanges();
            return Ok();

        }*/

        public async Task<IActionResult> PutRegistration(int id, Registration registration)
        {
            if (id != registration.userid)
            {
                return BadRequest();
            }

          var res= await _registrationRepository.PutRegistration(id, registration);
          if(res != null)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }


        // POST: api/Registrations
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Registration>> PostRegistration(Registration registration)
        {
            await _registrationRepository.PostRegistration(registration);

            return CreatedAtAction("GetRegistration", new { id = registration.userid }, registration);
        }


        // DELETE: api/Registrations/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Registration>> DeleteRegistration(int id)
        {
            try
            {
                return await _registrationRepository.DeleteRegistration(id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return NotFound();
            }
        }


        /*private bool RegistrationExists(int id)
        {
            return _context.Registrations.Any(e => e.userid == id);
        }*/

    }
}
