﻿namespace ComedyShow.DTO
{
    public class UserDto
    {

        public int userid { get; set; }

        public string username { get; set; }

        public string email { get; set; }

        public string password { get; set; }

        public string confirmpassword { get; set; }

    }
}
