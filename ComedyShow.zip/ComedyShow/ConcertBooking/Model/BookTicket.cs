﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ComedyShow.Model
{
    public class BookTicket
    {

        [Key]
        public long Bookid { get; set; }
        public int? Seatnum { get; set; }
        [ForeignKey("ComedyShowId")]
        public int? ComedyShowId { get; set; }
        [ForeignKey("UserId")]
        public int? UserId { get; set; }
        public DateTime? Date { get; set; }
        public virtual FindTicket ComedyShow { get; set; }
        public virtual Registration User { get; set; }
    }
}
