﻿using System.ComponentModel.DataAnnotations;

namespace ComedyShow.Model
{
    public class FindTicket
    {
        [Key]
        public int ComedyShowId { get; set; }
        public string Location { get; set; }
        public string TheaterName { get; set; }
        [Required(ErrorMessage = "ComedyShow name is required")]
        public string ComedyShowName { get; set; }

        public string Slot { get; set; }
        public int charges { get; set; }

        [Required(ErrorMessage = "Date is required")]
        public DateTime? date { get; set; }
        public string ComedyShowLink { get; set; }
    }
}
