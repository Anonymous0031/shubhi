﻿namespace ComedyShow.Model
{
    public class Registrationdto
    {
        public string Token { get; set; }
    }
}
