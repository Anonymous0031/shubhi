﻿using ComedyShow.Controllers;
using ComedyShow.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ComedyShow.Repository
{
    public class BookTicketRepository:IBookTicket
    {
        private readonly ComedyShowDbContext _context;
        private readonly ILogger<BookTicketsController> _logger;
        private readonly IConfiguration configuration;
        public BookTicketRepository(ComedyShowDbContext context, ILogger<BookTicketsController> logger, IConfiguration configuration)
        {
            _context = context;
            _logger = logger;
            this.configuration = configuration;
        }
        public async Task<ActionResult<IEnumerable<BookTicket>>> GetBookTicket()
        {
            return await _context.BookTickets.ToListAsync();
        }

        public async Task<ActionResult<IEnumerable<BookTicket>>> GetBookTicketsByUserId(long userId)
        {
            var book = await _context.BookTickets.Where(t => t.UserId == userId).ToListAsync();

            return book;
        }

        public async Task<ActionResult<BookTicket>> PostBookTicket(BookTicket bookTicket)
        {
            _context.BookTickets.Add(bookTicket);
            await _context.SaveChangesAsync();
            return bookTicket;
        }

        public async Task<ActionResult<BookTicket>> PutBookTicket(int id, BookTicket bookTicket)
        {
            _context.Entry(bookTicket).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return bookTicket;
        }

        public async Task<ActionResult<BookTicket>> DeleteBookTicket(long id)
        {
            var bookTicket = await _context.BookTickets.FindAsync(id);
            _context.BookTickets.Remove(bookTicket);
            await _context.SaveChangesAsync();
            return bookTicket;
        }


        private bool BookTicketExists(long id)
        {
            return _context.BookTickets.Any(e => e.Bookid == id);
        }
    }
}
