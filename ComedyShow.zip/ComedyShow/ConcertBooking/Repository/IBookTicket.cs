﻿using ComedyShow.Model;
using Microsoft.AspNetCore.Mvc;

namespace ComedyShow.Repository
{
    public interface IBookTicket
    {
        Task<ActionResult<IEnumerable<BookTicket>>> GetBookTicket();
        Task<ActionResult<IEnumerable<BookTicket>>> GetBookTicketsByUserId(long userId);
        Task<ActionResult<BookTicket>> PostBookTicket(BookTicket bookTicket);
        Task<ActionResult<BookTicket>> PutBookTicket(int id, BookTicket bookTicket);
        Task<ActionResult<BookTicket>> DeleteBookTicket(long id);

    }
}
