﻿using ComedyShow.Controllers;
using ComedyShow.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ComedyShow.Repository
{
    public class RegistrationRepository : IRegistrationRepository
    {
        private readonly ComedyShowDbContext _context;
        private readonly ILogger<RegistrationsController> _logger;
        private readonly IConfiguration configuration;
        public RegistrationRepository(ComedyShowDbContext context, ILogger<RegistrationsController> logger, IConfiguration configuration)
        {
            _context = context;
            _logger = logger;
            this.configuration = configuration;
        }
        public async Task<ActionResult<IEnumerable<Registration>>> GetRegistration()
        {
            return await _context.Registrations.ToListAsync();
        }

        public async Task<ActionResult<Registration>> GetRegistration(int id)
        {
            var registration = await _context.Registrations.FindAsync(id);

            return registration;
        }

        public async Task<Registrationdto> GetRegistration(string email, string password)
        {
            var userExist = _context.Registrations.FirstOrDefault(t => t.email == email && EF.Functions.Collate(password, "SQL_Latin1_General_CP1_CS_AS") == password);
            if (userExist != null)
            {
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                var claims = new[]
                {
         new Claim(ClaimTypes.Email,userExist.email),
         new Claim("UserId",userExist.userid.ToString()),
         new Claim(ClaimTypes.Role,userExist.usertype)
     };
                var token = new JwtSecurityToken(configuration["Jwt:Issuer"], configuration["Jwt:Audience"], claims, expires: DateTime.Now.AddMinutes(30), signingCredentials: credentials);
                var jwtToken = new JwtSecurityTokenHandler().WriteToken(token);
                var dto = new Registrationdto
                {
                    Token = jwtToken,
                };
                return dto;
            }
            return null;
        }
        public async Task<ActionResult<Registration>> PostRegistration(Registration registration)
        {
            _context.Registrations.Add(registration);
            await _context.SaveChangesAsync();
            return registration;
        }

        public async Task<ActionResult<Registration>> PutRegistration (int id, Registration registration)
        {
            /*context.Entry(registration).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return registration;*/
            var user = _context.Registrations.FirstOrDefault(t => t.userid == registration.userid);
            if (user != null)
            {
                user.username = registration.username;
                user.password = registration.password;
                user.email = registration.email;
                user.confirmpassword = registration.confirmpassword;

            }
            _context.SaveChanges();
            return user;

        }

        public async Task<ActionResult<Registration>> DeleteRegistration(int id)
        {
            var registration = await _context.Registrations.FindAsync(id);
            _context.Registrations.Remove(registration);
            await _context.SaveChangesAsync();
            return registration;
        }

        private bool RegistrationExists(int id)
        {
            return _context.Registrations.Any(e => e.userid == id);
        }
    }
}
